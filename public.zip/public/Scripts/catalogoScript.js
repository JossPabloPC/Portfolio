const storage = firebase.storage(); //Objeto de la base

const proyectosDiv = document.getElementById("catalogoDeProyectos"); //Obtiene el Div donde se desplegarán los proyectos
const categoriasDiv = document.getElementById("categorias"); //Obtiene el Div donde se desplegarán las categorás



const ModalTitle = document.getElementById("modalTitleProyecto"); //Obtiene el Div donde se desplegarán las categorás
const ModalDesc = document.getElementById("modalDesc"); //Obtiene el Div donde se desplegarán las categorás
const ModalButton = document.getElementById("modalButton"); //Obtiene el Div donde se desplegarán las categorás

const onGetProyectos = (callback) => db.collection('Proyecto').onSnapshot(callback); //Función llamada cada que se actualiza la base
const displayedProyectos = [];
const listaCategorias = [];
let currentCategoria = "Todos";



onGetProyectos((listProyectos) => {
    proyectosDiv.innerHTML = "";
    categoriasDiv.innerHTML = `
    <button class = "btn btn-primary btnCategoria d-inline mb-3" value="Todos" btn>Todos</buttton>`;
    listProyectos.forEach((doc) => {
        const proyecto = doc.data();
        proyecto.id = doc.id;

        setCategorias(proyecto);

        showSelected(proyecto);

        //setHeader(listaDeProyectos);
        titlesClick(doc);
    })
    const btnCategorias = document.querySelectorAll('.btnCategoria');
    btnCategorias.forEach(btn => {
        btn.addEventListener('click', e => {
            currentCategoria = btn.value;
            proyectosDiv.innerHTML = "";
            onGetProyectos((listProyectos) => {
                listProyectos.forEach((doc) => {
                    const proyecto = doc.data();
                    proyecto.id = doc.id;
                    
                    showSelected(proyecto);
                    titlesClick(doc);

                })
            })
        })
    })

})


//EVENTOS


//FUNCIONES
const getProyectos = () => db.collection('Proyecto').get(); //Obtiene todo de la base 
const getProyectoByID = (id) => db.collection('Proyecto').doc(id).get(); //Obtiene un proyecto en específico

function titlesClick(doc) {//Despliega la info de cada proyecto cada vez que se hace click en un título
    const titles = document.querySelectorAll('.proyectoTitle');
    titles.forEach(title => {//Recorre todos los títulos 
        title.addEventListener('click', async (e) => {//Les asigna el evento del click al texto

            const AllDesc = document.querySelectorAll('.descProject');
            AllDesc.forEach(desc => {
                desc.innerHTML = ""
            })

            selectedProyecto = await getProyectoByID(e.target.dataset.id)
            selectedProyecto = selectedProyecto.data()
            //console.log(selectedProyecto);
            ModalTitle.innerHTML = selectedProyecto.title;
            ModalDesc.innerHTML = `
            <div class = "card card-body mt-2 border primary">
            <p>${selectedProyecto.descriptionCorta}</p>
            <img src="${selectedProyecto.URLDownload}" class="img-fluid" alt="Responsive image"><br>
        </div>`;


            const btnKnowMore = document.getElementById('ProyectBtn');//Boton que muestra el preview del proyecto
            console.log(btnKnowMore);
            btnKnowMore.addEventListener('click', e => {
                console.log("Should Open");
                window = window.open("../pages/paginaProyecto.html", "_self");
                window.document.write(setProjectHTLM(selectedProyecto.title, selectedProyecto.descriptionCorta, selectedProyecto.descriptionLarga, selectedProyecto.URLDownload));
            })


        })
    })
}

function setCategorias(proyecto) {
    if (!listaCategorias.includes(proyecto.Categoria)) {//Checa si la categoría existe
        listaCategorias.push(proyecto.Categoria);
        categoriasDiv.innerHTML += `
            <button class = "btn btn-primary btnCategoria d-inline mb-3" id="${proyecto.id}" value="${proyecto.Categoria}" btn>${proyecto.Categoria}</buttton>
        `
    }

 //   const btnCategorias = document.querySelectorAll('.btnCategoria');
 //   btnCategorias.forEach(btn => {
 //       btn.addEventListener('click', e => {
 //           currentCategoria = btn.value;
 //           proyectosDiv.innerHTML = "";
 //           onGetProyectos((listProyectos) => {
 //               listProyectos.forEach((doc) => {
 //                   const proyecto = doc.data();
 //                   proyecto.id = doc.id;
 //                   
 //                   showSelected(proyecto);
 //                   titlesClick(doc);
//
 //               })
 //           })
 //       })
 //   })

}


function showSelected(proyecto) {
    //console.log(currentCategoria == "Todos");
    //console.log(displayedProyectos.includes(proyecto.id) && proyecto.Categoria == currentCategoria);
    if (!displayedProyectos.includes(proyecto.id  && proyecto.Categoria == currentCategoria)) {
        displayedProyectos.push(proyecto.id);
    }    
    if (currentCategoria == "Todos" || proyecto.Categoria == currentCategoria) {
        proyectosDiv.innerHTML += `
            <div class = "row">
            <div class = "col-12">
            <div class="border.primary mt-4">
            <h3 class= "proyectoTitle" id="${proyecto.title}" data-id="${proyecto.id}" data-toggle="modal" data-target="#ProyectoModal">${proyecto.title}</h3>
            </div>
            <div class="descProject row" id="${proyecto.id}desc"></div>
            </div>
            </div>
            `
    }
}

function setProjectHTLM(title, descCorta, descLarga, url) {
    return `<!doctype html>
    <html lang="en">
    
    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    
        <!--Fuentes-->
        <style>
            @import url("https://fonts.googleapis.com/css2?family=Nunito:wght@600&display=swap");
            @import url("https://fonts.googleapis.com/css2?family=Anton&display=swap");
        </style>
    
        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"
            integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
        <link rel="stylesheet" href="../css/styles.css">
        <title></title>
    </head>
    
    <body>
        <!--Nav Bar-->
        <nav class="navbar navbar-expand-md bg-dark navbar-dark">
            <a class="navbar-brand" href="../index.html">Página principal</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="collapsibleNavbar">
                <ul class="navbar-nav" id="navbar-content">
                    <li class="nav-item">
                        <a class="nav-link" href="catalogo.html">Proyectos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="contact.html">Contacto</a>
                    </li>
                    <li class="nav-item">
                     <a class="nav-link" href="pages/controlador.html">CRUD</a>
                    </li>
                </ul>
            </div>
        </nav>

        <div class="containerPrimario fluid-container p-4">
            <h2>${title}</h2>
            <p>${descCorta}</p>
            <img src="${url}" class="img-fluid" alt="Responsive image"><br>
            <p>${descLarga}</p>
        </div>
    
        <!--Footer-->
    <div class="footer-copyright text-center py-3">
        <div
        <p>
          Ciudad de México, México<br />
          Cel: 55 30 40 44 19<br />
          Correo:
          <a class="mailto" href="mailto:pc.josepablo@gmail.com"
            >pc.josepablo@gmail.com</a
          >
          <br />
          Instagram:
          <a href="https://www.instagram.com/joss.pablo.pc/" target="blank"
            >@joss.pablo.pc</a
          >
          <br>
          <a href="https://jossp.itch.io/" target="blank"
            >itch.io</a
          >
          <br>
          
          JossPabloPC©
        </p>
      </div>
    </div>


        <!--Scripts-->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    
        <!-- The core Firebase JS SDK is always required and must be listed first -->
        <script src="https://www.gstatic.com/firebasejs/7.23.0/firebase-app.js"></script>
    
        <!-- TODO: Add SDKs for Firebase products that you want to use
        https://firebase.google.com/docs/web/setup#available-libraries -->
        <script src="https://www.gstatic.com/firebasejs/7.23.0/firebase-analytics.js"></script>
        <script src="https://www.gstatic.com/firebasejs/7.23.0/firebase-firestore.js"></script>
        <script src="https://www.gstatic.com/firebasejs/7.23.0/firebase-storage.js"></script>
    
        <script>
            // Your web app's Firebase configuration
            // For Firebase JS SDK v7.20.0 and later, measurementId is optional
            var firebaseConfig = {
                apiKey: "AIzaSyDSQCEE5yamt4RJ9k5oNeetT7DJF4iFm6w",
                authDomain: "pablopenalozacobos.firebaseapp.com",
                databaseURL: "https://pablopenalozacobos.firebaseio.com",
                projectId: "pablopenalozacobos",
                storageBucket: "pablopenalozacobos.appspot.com",
                messagingSenderId: "501359530575",
                appId: "1:501359530575:web:f63184795ae8b6ce5a903a",
                measurementId: "G-WWK27V4X6L"
            };
            // Initialize Firebase
            firebase.initializeApp(firebaseConfig);
            firebase.analytics();
        </script>
    
    
    </body>
    
    </html>`;
}