const storage = firebase.storage().ref();

const Form = document.getElementById("ProyectosForm"); //Lee la forma
const proyectoDivList = document.getElementById("proyectosListDiv");//Div donde despliega los datos
const usuariosList = document.getElementById("dropdownMenu");//Div donde despliega los usuarios
const adminsList = document.getElementById("admins");//Div donde despliega los usuarios



let listaCategorias = [];

let editStatus = false;
let idx = '';

Form.onsubmit = async e => { //Función que se ejecuta cuando se sube la forma
    e.preventDefault();

    const title = Form['ProyectosTitle'].value;
    const descCorta = Form['ProyectosDescCorta'].value;
    const descLarga = Form['ProyectosDescLarga'].value;
    const img = Form['ProyectosImg'].files[0];
    const categoria = Form['Categoria'].value;

    const url = await subirImagen(img);
    listaCategorias= [];

    if (!editStatus) {
        categoriasDiv.innerHTML = `
        <button class = "btn btn-primary btnCategoria d-inline mb-3" value="Todos" btn>Todos</buttton>`;
        await salvarProyecto(title, descCorta, descLarga, url, categoria);
    }
    else {
         categoriasDiv.innerHTML = `
        <button class = "btn btn-primary btnCategoria d-inline mb-3" value="Todos" btn>Todos</buttton>`;
        let url = await subirImagen(img);
        console.log(url);
        await updateTask(idx, {
            title: title,
            descriptionCorta: descCorta,
            descriptionLarga: descLarga,
            Categoria: categoria,
            URLDownload: url
        });
    }

    editStatus = false;
    id = '';
    Form['BtnProyecto'].innerText = 'Save';

    getProyectos();

    Form.reset();

}

const onGetUsuarios = (callback) => db.collection('Usuarios').onSnapshot(callback);
const getUsuario = (id) => db.collection('Usuarios').doc(id).get();
const updateUsuario = (id, updatedDesc) => db.collection("Usuarios").doc(id).update(updatedDesc);



const getProyectos = () => db.collection('Proyecto').get(); //Obtiene todo de la base 

const onGetProyectos = (callback) => db.collection('Proyecto').onSnapshot(callback);

const getProyecto = (id) => db.collection('Proyecto').doc(id).get();

const deleteProyecto = id => db.collection('Proyecto').doc(id).delete();

const updateTask = (id, updatedDesc) => db.collection("Proyecto").doc(id).update(updatedDesc);

const categoriasDiv = document.getElementById("categorias");

window.addEventListener("DOMContentLoaded", async (e) => {//Evento que se ejecuta cuando cargala página 
    onGetProyectos((listProyectos) => {
        proyectoDivList.innerHTML = "";
        categoriasDiv.innerHTML = `
        <button class = "btn btn-primary btnCategoria d-inline mb-3" value="Todos" btn>Todos</buttton>`;
        listProyectos.forEach((doc) => {


            const proyecto = doc.data();
            proyecto.id = doc.id;

            setCategorias(proyecto);
            proyectoDivList.innerHTML += `
        <div class = "card card-body mt-2 border primary">
        <h3>${proyecto.title}</h3>
        <p>${proyecto.descriptionCorta}<p>
        <p>${proyecto.descriptionLarga}<p>
        <p>${proyecto.Categoria}<p>
        <img src="${proyecto.URLDownload}" class="img-fluid" alt="Responsive image"><br>
        <div>
            <button class = "btn btn-primary btnDelete mt-3" data-id="${proyecto.id}">Delete</buttton>
            <button class = "btn btn-Secondary mt-3 btn-edit" data-id="${proyecto.id}">Edit</buttton>
        </div>
        </div>`

            const btnDelte = document.querySelectorAll('.btnDelete');
            btnDelte.forEach(btn => {
                btn.addEventListener('click', async (e) => {
                    await deleteProyecto(e.target.dataset.id);
                })
            })

            const btnsEdit = document.querySelectorAll('.btn-edit');
            btnsEdit.forEach(btn => {
                btn.addEventListener('click', async (e) => {
                    const currentProyecto = await getProyecto(e.target.dataset.id);

                    editStatus = true;
                    idx = currentProyecto.id;
                    console.log(idx);

                    Form['ProyectosTitle'].value = currentProyecto.data().title;
                    Form['ProyectosDescCorta'].value = currentProyecto.data().descriptionCorta;
                    Form['ProyectosDescLarga'].value = currentProyecto.data().descriptionLarga;
                    Form['Categoria'].value = currentProyecto.data().Categoria;
                    Form['ProyectosImg'].files[0] =currentProyecto.data().URLDownload;


                    Form['BtnProyecto'].innerText = 'Update';

                })
            })
        });
        
        const btnCategorias = document.querySelectorAll('.btnCategoria');
        btnCategorias.forEach(btn => {
            btn.addEventListener('click', e => {
                currentCategoria = btn.value;
                proyectoDivList.innerHTML = "";
                onGetProyectos((listProyectos) => {
                    listProyectos.forEach((doc) => {
                        const proyecto = doc.data();
                        proyecto.id = doc.id;

                        showSelected(proyecto);

                    })
                })
            })
        })
    })
    const btnCategorias = document.querySelectorAll('.btnCategoria');
    btnCategorias.forEach(btn => {
        btn.addEventListener('click', e => {
            currentCategoria = btn.value;
            proyectoDivList.innerHTML = "";
            onGetProyectos((listProyectos) => {
                listProyectos.forEach((doc) => {
                    const proyecto = doc.data();
                    proyecto.id = doc.id;
                    showSelected(proyecto);
                })
            })
        })
    })

    onGetUsuarios((listUsuarios) => {
        adminsList.innerHTML=``;
        usuariosList.innerHTML=``;
        listUsuarios.forEach((doc) => {
            const usuario = doc.data();
            usuario.id = doc.id;
            usuariosList.innerHTML+=`<button class="usuario dropdown-item" data-id="${usuario.id}" href="#">${usuario.correo}</button>`
            if(usuario.isAdmin)
                adminsList.innerHTML+=`<p>${usuario.correo}</p>`;

        })
        const btnUsuarios = document.querySelectorAll('.usuario');
        btnUsuarios.forEach((usr) => {
            usr.addEventListener('click',async e => {
                e.preventDefault();
                //console.log("Usuario selecionado:", e.target.dataset.id);
                const usuario = await getUsuario(e.target.dataset.id)
                console.log("Se hará admin a: ", e.target.dataset.id);
                await updateUsuario(e.target.dataset.id, {
                    correo: usuario.data().correo,
                    contraseña:usuario.data().contraseña,
                    isAdmin: true
                });
                console.log(usuario.data());
            })
        })
    });


});


const salvarProyecto = (title, descCorta, descLarga, URLDownload, categoria) => {//Guarda lo escrito en la forma en la base de datos 
    console.log(URLDownload);
    db.collection('Proyecto').doc().set({ //Acceder a la base de datos puede tardar. Le indicamos que espere a que se ejecute
        title: title,
        descriptionCorta: descCorta,
        descriptionLarga: descLarga,
        URLDownload: URLDownload,
        Categoria: categoria
    });

    console.log("subido")

}

function setCategorias(proyecto) {
    if (!listaCategorias.includes(proyecto.Categoria)) {//Checa si la categoría existe
        listaCategorias.push(proyecto.Categoria);
        categoriasDiv.innerHTML += `
            <button class = "btn btn-primary btnCategoria d-inline mb-3" id="${proyecto.id}" value="${proyecto.Categoria}" btn>${proyecto.Categoria}</buttton>
        `
    }

//    const btnCategorias = document.querySelectorAll('.btnCategoria');
//    btnCategorias.forEach(btn => {
//        btn.addEventListener('click', e => {
//            currentCategoria = btn.value;
//            proyectoDivList.innerHTML = "";
//            onGetProyectos((listProyectos) => {
//                listProyectos.forEach((doc) => {
//                    const proyecto = doc.data();
//                    proyecto.id = doc.id;
//                    showSelected(proyecto);
//                })
//            })
//        })
//    })
}

function showSelected(proyecto) {
    //console.log(currentCategoria == "Todos");


    if (currentCategoria == "Todos" || proyecto.Categoria == currentCategoria) {
        proyectoDivList.innerHTML += `
        <div class = "card card-body mt-2 border primary">
        <h3>${proyecto.title}</h3>
        <p>${proyecto.descriptionCorta}<p>
        <p>${proyecto.descriptionLarga}<p>
        <p>${proyecto.Categoria}<p>
        <img src="${proyecto.URLDownload}" class="img-fluid" alt="Responsive image"><br>
        <div>
            <button class = "btn btn-primary btnDelete mt-3" data-id="${proyecto.id}">Delete</buttton>
            <button class = "btn btn-Secondary mt-3 btn-edit" data-id="${proyecto.id}">Edit</buttton>
        </div>
        </div>`

        const btnDelte = document.querySelectorAll('.btnDelete');
        btnDelte.forEach(btn => {
            btn.addEventListener('click', async (e) => {
                await deleteProyecto(e.target.dataset.id);
            })
        })

        const btnsEdit = document.querySelectorAll('.btn-edit');
        btnsEdit.forEach(btn => {
            btn.addEventListener('click', async (e) => {
                const currentProyecto = await getProyecto(e.target.dataset.id);

                editStatus = true;
                idx = currentProyecto.id;
                console.log(idx);

                Form['ProyectosTitle'].value = currentProyecto.data().title;
                Form['ProyectosDescCorta'].value = currentProyecto.data().descriptionCorta;
                Form['ProyectosDescLarga'].value = currentProyecto.data().descriptionLarga;
                Form['Categoria'].value = currentProyecto.data().Categoria;


                Form['BtnProyecto'].innerText = 'Update';

            })
        })
    }
}

async function subirImagen(img){
    const name = new Date() + "-" + img.name;//nombre del archivo
    const metadata = { contentType: img.type };//metadata del archivo
    const snapshot = await storage.child(name).put(img, metadata)//Sube el archivo
    const url = await snapshot.ref.getDownloadURL();
    return url;
}





//Control de usuarios
//José Pablo Peñaloza Cobos
//NOV-2020

////VARIABLES///
//elementos del html
const signUp = document.getElementById("signUp-form");//Forma del signUP
const signIn = document.getElementById("signIn-form");//Forma del signIn
const logOut = document.getElementById("LogOutBtn");//Forma del signIn
const userNavBar = document.getElementById("userNav");//Texto del navbar del usuario loggeado

const getUser = (id) => db.collection('Usuarios').doc(id).get();


//Eventos
signUp.onsubmit = async e => { //Función que se ejecuta cuando se sube la forma de añadir un ususario
    e.preventDefault();
    const email = document.getElementById("signup-email").value;//Valor del correo que se sube
    const password = document.getElementById("signup-password").value;//Valor de la nueva contraseña

    auth
        .createUserWithEmailAndPassword(email, password)//Se registra el usuario
        .then(userCredential => {//Recibe las credenciales del usuario
            signUp.reset();//Reseta el form
            $('#SignUpModal').modal('hide')//Busca el modal y lo esconde
            console.log('Correo registrado')
        })

    salvarUsuario(email, password);
    auth
}
signIn.addEventListener('submit', (e) => {//Evento que se ejecuta cuando se sube en sign in
    e.preventDefault();//Evita que la página se recarge al subir el form

    const email = document.getElementById("Login-email").value;//Valor del correo que se sube
    const password = document.getElementById("Login-password").value;//Valor de la contraseña

    auth
        .signInWithEmailAndPassword(email, password)//Se loggea el usuario
        .then(userCredential => {//Recibe las credenciales del usuario
            signIn.reset();//Reseta el form
            $('#SignInModal').modal('hide')//Busca el modal y lo esconde
            console.log('Loggeo')

        })
        
})
logOut.addEventListener('click', (e) => {//Evento que se ejecuta cuando se hace clik en el boton de log out.
    e.preventDefault();
    auth.signOut().then(() => {
        console.log("Ya no estas loggeado");
    })
})
window.addEventListener("DOMContentLoaded", async (e) => {//Evento que se ejecuta cuando cargala página 
});

auth.onAuthStateChanged(async(user) => {//Evento que se ejecuta cada que hay un 
    const CRUDBTn = document.getElementById("Info");//Botón del navbar del CRUD
    if (user) {
        console.log("loggeado", user.email)
        userNavBar.innerHTML = `${user.email}`;
        let boolisAdmin = await isAdmin(user.email);  
        if(boolisAdmin){
            userNavBar.innerHTML += "👑";
            CRUDBTn.style.display = "block";
        }
        else
            CRUDBTn.style.display = "none";

    }
    else {
        console.log("no estas loggeado")
        userNavBar.innerHTML = ``
        CRUDBTn.style.display = "none;"
    }
})



//Funciones
const salvarUsuario = (correo, contraseña) => {//Guarda lo escrito en la forma en la base de datos 
    db.collection('Usuarios').doc(correo).set({ //Acceder a la base de datos puede tardar. Le indicamos que espere a que se ejecute
        correo: correo,
        contraseña: contraseña,
        isAdmin: false
    });

    console.log("subido")
}

async function isAdmin(id){
    const usuario = await getUser(id);
    console.log(usuario.data().isAdmin)
    if(usuario.data().isAdmin)
        return true;
    else
        return false;
}

